package edu.skku.cs.pa1;

public class Guesscontents_yellow {
    public String alphabet_yellow;

    public Guesscontents_yellow(String alphabet_yellow){
        this.alphabet_yellow = alphabet_yellow;
    }
}
