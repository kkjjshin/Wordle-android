package edu.skku.cs.pa1;

public class InputWordle {
    public String alphabet1;
    public String alphabet2;
    public String alphabet3;
    public String alphabet4;
    public String alphabet5;
    public String tvColor1;
    public String tvColor2;
    public String tvColor3;
    public String tvColor4;
    public String tvColor5;


    public InputWordle (String alphabet1,String alphabet2,String alphabet3,
                        String alphabet4,String alphabet5,String tvColor1,
                        String tvColor2,String tvColor3,String tvColor4,String tvColor5){


        this.alphabet1 = alphabet1;
        this.alphabet2 = alphabet2;
        this.alphabet3 = alphabet3;
        this.alphabet4 = alphabet4;
        this.alphabet5 = alphabet5;
        this.tvColor1 =  tvColor1;
        this.tvColor2 =  tvColor2;
        this.tvColor3 =  tvColor3;
        this.tvColor4 =  tvColor4;
        this.tvColor5 =  tvColor5;



    }
}
