package edu.skku.cs.pa1;

public class Guesscontents_gray {
    public String alphabet_gray;

    public Guesscontents_gray(String alphabet_gray){
        this.alphabet_gray = alphabet_gray;
    }

}
