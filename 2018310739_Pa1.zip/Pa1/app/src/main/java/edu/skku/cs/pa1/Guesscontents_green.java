package edu.skku.cs.pa1;

public class Guesscontents_green {
    public String alphabet_green;

    public Guesscontents_green(String alphabet_green){
        this.alphabet_green = alphabet_green;
    }
}
